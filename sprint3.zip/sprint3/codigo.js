// script.js

document.addEventListener('DOMContentLoaded', () => {
    // Carregar elogios selecionados para o perfil
    function loadProfileKeywords() {
        const selectedKeywords = JSON.parse(localStorage.getItem('profileKeywords')) || [];
        const selectedKeywordsDiv = document.getElementById('selectedKeywords');
        selectedKeywordsDiv.innerHTML = ''; // Limpar elogios anteriores
        selectedKeywords.forEach(keyword => {
            const keywordDiv = document.createElement('div');
            keywordDiv.textContent = keyword;
            selectedKeywordsDiv.appendChild(keywordDiv);
        });
    }

    // Adicionar elogio ao perfil
document.getElementById('addKeywordButton').addEventListener('click', () => {
    console.log('Botão de adicionar clicado');
    const selectedKeyword = document.getElementById('keywordSelect').value;
    console.log('Elogio selecionado:', selectedKeyword);
    if (selectedKeyword) {
        let profileKeywords = JSON.parse(localStorage.getItem('profileKeywords')) || [];
        console.log('Elogios salvos:', profileKeywords);
        if (!profileKeywords.includes(selectedKeyword)) {
            profileKeywords.push(selectedKeyword);
            localStorage.setItem('profileKeywords', JSON.stringify(profileKeywords));
            console.log('Elogio adicionado:', selectedKeyword);
            loadProfileKeywords();
        } else {
            console.log('Elogio já existe no perfil');
        }
    }
});

    localStorage.removeItem('profileKeywords');
    // Inicializar o perfil com os elogios carregados
    loadProfileKeywords();
});






