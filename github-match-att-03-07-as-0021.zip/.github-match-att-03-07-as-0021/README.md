# Perfil do Grupo de esportes Ciência da computação - PUC Minas

Seja bem-vindo ao nosso perfil do trabalho de Front-end! 👋 Somos estudante de Ciência da computação na PUC Minas, buscando constantemente aprender e contribuir para a comunidade de desenvolvimento. Abaixo, compartilho um pouco sobre nosso projeto.


## Sobre o projeto

  Quando o assunto é pratica de esportes em grupo nós identificamos um grande e comum problema, que é, encontrar pessoas que estejam disponíveis e dispostas a para a pratica da atividade, sendo assim o nosso site “GRUPO DE ESPORTE” vai ser desenvolvido com o propósito de facilitar a conexão entre pessoas com interesses esportivos similares e também para pessoas que desejam conhecer uma nova modalidade esportiva. 

  Seja você um atleta experiente ou alguém que está começando agora no mundo esportivo. Nosso público-alvo no momento são os universitários da PUC, mas também qualquer outra pessoa que deseje encontrar parceiros para a pratica de esportes. O sit# Perfil do Grupo de esportes Ciência da computação - PUC Minas

Seja bem-vindo ao nosso perfil do trabalho de Front-end! 👋 Somos estudante de Ciência da computação na PUC Minas, buscando constantemente aprender e contribuir para a comunidade de desenvolvimento. Abaixo, compartilho um pouco sobre nosso projeto.


## Sobre o projeto

  Quando o assunto é pratica de esportes em grupo nós identificamos um grande e comum problema, que é, encontrar pessoas que estejam disponíveis e dispostas a para a pratica da atividade, sendo assim o nosso site “GRUPO DE ESPORTE” vai ser desenvolvido com o propósito de facilitar a conexão entre pessoas com interesses esportivos similares e também para pessoas que desejam conhecer uma nova modalidade esportiva. 

  Seja você um atleta experiente ou alguém que está começando agora no mundo esportivo. Nosso público-alvo no momento são os universitários da PUC, mas também qualquer outra pessoa que deseje encontrar parceiros para a pratica de esportes. O site “GRUPO DE ESPORTES” é mais do que apenas uma plataforma para se encontrar parceiros esportivos é um espaço onde pessoas com interesses comuns podem se conectar, compartilhar experiências e fazer novas amizades enquanto praticam o esporte que amam.
e “GRUPO DE ESPORTES” é mais do que apenas uma plataforma para se encontrar parceiros esportivos é um espaço onde pessoas com interesses comuns podem se conectar, compartilhar experiências e fazer novas amizades enquanto praticam o esporte que amam.
